#define DTC_VERSION "DTC 1.4.2-Android-build"
