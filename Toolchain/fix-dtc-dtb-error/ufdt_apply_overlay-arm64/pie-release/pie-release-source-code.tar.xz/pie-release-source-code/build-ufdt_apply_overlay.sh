#!/bin/bash

cd sysdeps
aarch64-linux-gnu-gcc -shared libufdt_sysdeps_posix.c -Iinclude -fPIC -o libufdt_sysdeps.so
cp libufdt_sysdeps.so /usr/lib
cd ..
aarch64-linux-gnu-gcc -c ufdt_convert.c ufdt_node.c ufdt_node_pool.c ufdt_overlay.c ufdt_prop_dict.c -Iinclude -Isysdeps/include -fPIC
aarch64-linux-gnu-gcc -shared ufdt_convert.o ufdt_node.o ufdt_node_pool.o ufdt_overlay.o ufdt_prop_dict.o -lfdt -o libufdt.so
cp libufdt.so /usr/lib
cd tests/src
aarch64-linux-gnu-gcc ufdt_overlay_test_app.c util.c -I../../include -I../../sysdeps/include -lufdt -lufdt_sysdeps -o ufdt_apply_overlay

